stats(fragagent,0.0,1).
