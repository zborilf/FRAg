// in czech only


Cislovani je podivne
1. cislo je kolik jiz realny agent udelal kroku, od tohoto kroku se simuluje
2. cislo jde 'odzadu' jak simulator rozbaluje strom, v kazdem souboru jsou pak uvedeny vsechny behy

TODO, vylepsit
Co se prostredi tyce, musi byt obnoveno pro krok (1. cislo) agenta pro kazdy beh pred tim, nez se
  provede cesta od korene MCTS k aktualnimu stavu